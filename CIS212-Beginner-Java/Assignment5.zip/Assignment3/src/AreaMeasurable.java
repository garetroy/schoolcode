
public interface AreaMeasurable {
	double getArea();
}
