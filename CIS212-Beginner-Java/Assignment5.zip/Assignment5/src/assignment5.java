import java.awt.*;

import javax.swing.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import javax.swing.JFrame;


public class assingment5{
	
	public static void main(String[] args){
		ArrayList<String[]> data = new ArrayList<String[]>;
		readFile();
		selectionSort(data);
	}
	
	
	private void readFile(){		
	    try {
	    	URL dataSrc = new URL(
	    			"https://www.cs.uoregon.edu/Classes/14F/cis212/assignments/phonebook.txt");
	    URLConnection conn = dataSrc.openConnection();
	    	BufferedReader br = new BufferedReader(
	    			new InputStreamReader(conn.getInputStream())); 
	    	
	    //	BufferedReader brFile = new BufferedReader(
	    			//new FileReader("Usr/meng/Desktop/data.txt"));
	    	
	        String line = br.readLine();
	        
	        while (line != null) {
	        		String[] parts=line.split(" ");
	        		data.add(parts);
	            line = br.readLine();
	        }	       
	        br.close();
	    }
	    catch(Exception e){
	    	System.err.print("File reading error!");
	    	System.err.print(e.getMessage());
	    }
	    
	}
	
	public static void selectionSort(ArrayList<String[]> data){
		ArrayList<String[]> newarraylist = data;
		for(int i = 0; i < newarraylist.size(); i++){
			String[] dataLine=newarraylist.get(i);
			String currentminimum = newarraylist.get(dataLine[1].substring(0, dataLine[1].length()-1));
			for(int j=i+1; j < newarraylist.size(); j++){
				String[] dataLine=newarraylist.get(current);
				String current = newarraylist.get(dataLine[1].substring(0, dataLine[1].length()-1));
				if (currentminimum.compareTo(current) > 0){
					String[] temp = newarraylist.get(j);
					newarraylist.get(j) = newarraylist.get(i);
					newarraylist.get(i) = temp;

				}
		
			}


		
	}


}