package midterm;

public class Main {
	
	public void main(){
	if (-1 >= 0)
		 System.out.println("n > 0");
		 System.out.println("or n == 0");
}}
