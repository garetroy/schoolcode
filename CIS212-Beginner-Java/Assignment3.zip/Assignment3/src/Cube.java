
public class Cube extends Box{

	public Cube(double width, double length, double height){
		super(width,length,height);
	}
}
