#include <math330.h>
#include <math.h>

double arccos330(double angle)
{
    return acos(angle);
}
