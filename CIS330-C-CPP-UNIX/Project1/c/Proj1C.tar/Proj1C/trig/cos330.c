#include <math330.h>
#include <math.h>

double cos330(double angle)
{
    return cos(angle);
}
